""" ИНФО
|-------------------------------------------|
|   Задание: Создайте комплекс функций      |
|   для отрисовки золотых прямоугольников   |
|-------------------------------------------|
|   Предлагаю реализовать функции:          |
|   * calc_image_size - размер изображения  |
|   * rectangle_coords - координаты         |
|   * golden_rectangles - отрисовка         |
|   * дополнительные при необходимости      |
|-------------------------------------------|
|   * Реализовать весь функционал для       | 
|     цветного изображения (опционально)    |
|-------------------------------------------|
"""

import numpy as np
from PIL import Image
from lesson12 import fibonacci_closure


def calc_image_size(n, side):
    """
    Рассчитывает размер изображения
    для отрисовки золотых прямоугольников

    Args:
        n (int): количество прямоугольников
        side (int): длина стороны наименьшего прямоугольника

    Returns:
        Tuple[int, int]: размеры изображения
    """
    h = fibonacci_closure(n) * side
    w = fibonacci_closure(n + 1) * side
    return h, w


def calc_vector(n):
    """
    Рассчитывает направления присоединения
    n-го прямоугольника
    :param n: номер прямоугольника
    :return: направление
    """
    if n == 1:
        return 'begin'
    v = (n-1) % 4
    if v == 1:
        return 'left'
    elif v == 2:
        return 'down'
    elif v == 3:
        return 'right'
    else:
        return 'up'


def rectangle_coords(n, side, img_size):
    """
    Рассчитывает координаты прямоугольника
    по его номеру и единичной длине стороны 

    Args:
        n (int): номер прямоугольника
        side (int): единичная длина стороны
        img_size : размер изображения

    Returns:
        Tuple[int, int, int, int]: координаты прямоугольника
    """
    h, w = img_size
    x0, y0, x1, y1 = 0, 0, 100, 100
    return x0, y0, x1, y1


def golden_rectangles(n, side):
    """
    Отрисовывает разными цветами n золотых
    прямоугольников на изображении

    Args:
        n (int): количество прямоугольников
        side (int): единичная длина стороны
    """
    h, w = calc_image_size(n, side)
    src = np.zeros((2*h, 2*w))
    # TODO: Добавить обработку src
    
    # TODO: *Сделать изображение цветным (опционально)
    img = Image.fromarray(src, mode="L")
    img.show()
    # img.save('fibonacci.png')


if __name__ == '__main__':
    # количество золотых прямоугольников
    n = 7
    # Длина стороны первого прямоугольника в пикселях
    side = 20
    golden_rectangles(n, side)
    
    